Генерация таблиц по переданным параметрам: заголовок, количество строк и столбцов, цвет фона.
![Image alt](https://github.com/VictorPiskunovich/OOP_SEM4_LAB_1/blob/main/Screenshot_1.png)
